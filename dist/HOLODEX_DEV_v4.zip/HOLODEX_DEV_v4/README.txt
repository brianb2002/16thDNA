C-LO HOLODEX · Dev mode build · version 4 (November 14, 2026)
=============================================================

FILES
  index.html                     The app. Open it in Chrome or Edge.
  holodex-claude-artifact.html   The same app built as a Claude artifact page (the version published at
                                 https://claude.ai/artifact/8Kr2hgh3TNpQHNMMv2qyxN). Give this file to Claude
                                 to publish your own copy. It is a page fragment, not meant to open directly.
  source/                        Everything needed to rebuild both files.

WHAT THIS VERSION IS
  The Holodex 3D trading floor with the old design removed:
  - The old overlay widgets (top bar, balance tile, main chart panel, sidebar, camera dock) start hidden.
    Bring any of them back in Dev mode > Layers (tap the eye).
  - The room's own buttons, screens, ticker ring and spheres do nothing when tapped, long-pressed or
    dragged. Dragging to look around and zooming still work. The action
    "Room · old 3D desk functions on / off" turns the old room behavior back on.
  - The theme no longer flips between Day and Night on its own.

DEV MODE (the DEV button, bottom left, or Ctrl+Shift+D)
  Edit tab      + Add button and + New panel at the top. Label, style, action, size, position, rotate,
                tilt (back/forward, left/right), curve, depth.
  Buttons list  Sidebars, dropdowns, tab bars and checklists: one row per button with its own label and
                action, arrows to reorder, x to remove, + Add button for more.
  New panel...  In any action menu. Makes a panel page for that button. Select the panel and press
                "+ Add button inside" to fill it; those buttons can open more panels. Panels have Back and x.
  Import        Your own button images (PNG, JPG, WebP, GIF, SVG), kept under Insert > My buttons.
  Erase         Tap anything to delete it. Ctrl+Z undoes. Esc stops.
  Layers        Show / hide / lock any part of the page and every component you added.
  Changes       Full history with per-change undo. Export saves your layout as a file.
  Your layout is saved in your browser and comes back every time you open the page.

ACTION MENUS
  Your panels and pop-ups   The panels you made, plus + New panel...
  Old Holodex functions     Buy, Sell, Scan, Settings, cameras, scenes and the rest. These open the
                            Holodex's own panels.
  Other                     Custom link.

REBUILD
  cd source/holodex
  python3 build.py
  Writes source/holodex/index.html (the app) and source/dist/holodex-dev.html (the artifact page).
  shell.html is your HOLODEX-SHELL page exactly as you sent it; build.py applies every change on top.

NOTES
  - Inside a Claude artifact, the live relay (16hunnid.tech) is blocked, so the Holodex runs on its
    simulated feed there.
  - Autopilot only arms after you set a session bankroll and target in the Holodex Settings and press
    ARM SESSION. That is the Holodex's own safety rule.
  - Curve uses an SVG filter; it was checked in Chrome only.
Learning tool, not financial advice.
